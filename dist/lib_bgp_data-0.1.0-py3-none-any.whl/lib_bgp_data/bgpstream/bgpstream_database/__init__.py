#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""This package has db functionality for bgpstream events"""

from .bgpstream_database import BGPStream_DB
