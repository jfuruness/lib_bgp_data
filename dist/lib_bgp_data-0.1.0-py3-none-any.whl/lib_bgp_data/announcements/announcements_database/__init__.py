#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""This package has db functionality for caida bgp announcements"""

from .announcements_database import Announcements_DB
