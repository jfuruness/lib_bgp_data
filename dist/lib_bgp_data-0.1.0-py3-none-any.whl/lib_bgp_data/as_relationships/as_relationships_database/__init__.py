#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""This package has db functionality for caida as relationships"""

from .as_relationships_database import AS_Relationship_DB

