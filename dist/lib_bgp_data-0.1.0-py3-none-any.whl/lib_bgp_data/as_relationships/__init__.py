#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""This package collects as_relationship info and has db functionality"""

from .as_relationships_database import AS_Relationship_DB
from .caida_as_relationships import Caida_AS_Relationships_Parser
